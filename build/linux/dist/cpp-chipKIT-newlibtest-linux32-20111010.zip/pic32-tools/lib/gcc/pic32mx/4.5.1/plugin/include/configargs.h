/* Generated automatically. */
static const char configuration_arguments[] = "../../chipKIT-cxx/src45x/gcc/configure --target=pic32mx --disable-threads --enable-static --disable-libmudflap --disable-libssp --disable-libstdcxx-pch --disable-hosted-libstdcxx --with-arch=pic32mx --enable-sgxx-sde-multilib --with-gnu-as --with-gnu-ld --enable-languages=c,c++ --disable-shared --disable-nls --with-dwarf2 --disable-bootstrap --enable-obsolete --disable-sjlj-exceptions --disable-__cxa_atexit --disable-libfortran --prefix=/Users/kjason/github-jasonkajita/linux-image --libexecdir=/Users/kjason/github-jasonkajita/linux-image/pic32mx/bin --with-bugurl=http://chipkit.org/forum --disable-libgomp --disable-libffi --program-prefix=pic32- --with-newlib --with-headers=/Users/kjason/github-jasonkajita/linux-image/pic32mx/include 'XGCC_FLAGS_FOR_TARGET=-fno-rtti -fno-enforce-eh-specs' --enable-cxx-flags='-fno-exceptions -ffunction-sections' --enable-poison-system-directories --host=i586-pc-linux --build=i686-apple-darwin10 --with-gmp=/Users/kjason/github-jasonkajita/linux-build/host-libs";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "arch", "pic32mx" }, { "synci", "no-synci" } };
